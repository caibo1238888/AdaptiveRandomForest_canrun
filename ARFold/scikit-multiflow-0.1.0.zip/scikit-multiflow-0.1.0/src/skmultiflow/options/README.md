## Module
Options Module - all option handlers based on the same abstract option class.

### Categories
* Options

### Functionality
* Handle different kinds of options

