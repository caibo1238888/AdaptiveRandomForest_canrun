"""
A Multi-output Streaming Framework
==================================
`scikit-multiflow` is a multi-output/multi-label and stream data mining framework for the
Python programming language.
"""