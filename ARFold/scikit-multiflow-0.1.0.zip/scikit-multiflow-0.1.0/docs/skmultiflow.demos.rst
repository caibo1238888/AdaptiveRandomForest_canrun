skmultiflow.demos package
=========================

Module contents
---------------

.. automodule:: skmultiflow.demos
    :members:
    :undoc-members:
    :show-inheritance:
