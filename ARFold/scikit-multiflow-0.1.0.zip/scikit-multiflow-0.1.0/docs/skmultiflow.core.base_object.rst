skmultiflow.core.base\_object module
====================================

.. automodule:: skmultiflow.core.base_object
    :members:
    :undoc-members:
    :show-inheritance:
