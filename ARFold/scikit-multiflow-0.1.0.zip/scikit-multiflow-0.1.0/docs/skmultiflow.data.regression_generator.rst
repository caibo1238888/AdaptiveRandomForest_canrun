skmultiflow.data.regression\_generator module
=============================================

.. automodule:: skmultiflow.data.regression_generator
    :members:
    :undoc-members:
    :show-inheritance:
