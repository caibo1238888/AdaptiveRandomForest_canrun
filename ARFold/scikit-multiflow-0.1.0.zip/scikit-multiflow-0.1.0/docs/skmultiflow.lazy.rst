skmultiflow.lazy package
========================

Submodules
----------

.. toctree::

   skmultiflow.lazy.distances
   skmultiflow.lazy.kdtree
   skmultiflow.lazy.knn
   skmultiflow.lazy.knn_adwin
   skmultiflow.lazy.sam_knn

Module contents
---------------

.. automodule:: skmultiflow.lazy
    :members:
    :undoc-members:
    :show-inheritance:
