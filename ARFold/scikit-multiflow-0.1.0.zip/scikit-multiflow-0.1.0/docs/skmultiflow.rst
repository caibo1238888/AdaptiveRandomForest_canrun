skmultiflow package
===================

Subpackages
-----------

.. toctree::

    skmultiflow.bayes
    skmultiflow.core
    skmultiflow.data
    skmultiflow.drift_detection
    skmultiflow.evaluation
    skmultiflow.lazy
    skmultiflow.meta
    skmultiflow.metrics
    skmultiflow.neural_networks
    skmultiflow.transform
    skmultiflow.trees
    skmultiflow.utils
    skmultiflow.visualization

Module contents
---------------

.. automodule:: skmultiflow
    :members:
    :undoc-members:
    :show-inheritance:
