skmultiflow.data.stagger\_generator module
==========================================

.. automodule:: skmultiflow.data.stagger_generator
    :members:
    :undoc-members:
    :show-inheritance:
