skmultiflow.meta.multi\_output\_learner module
==============================================

.. automodule:: skmultiflow.meta.multi_output_learner
    :members:
    :undoc-members:
    :show-inheritance:
