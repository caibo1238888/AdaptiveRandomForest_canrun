skmultiflow.trees.intra\_cluster\_variance\_reduction\_split\_criterion module
==============================================================================

.. automodule:: skmultiflow.trees.intra_cluster_variance_reduction_split_criterion
    :members:
    :undoc-members:
    :show-inheritance:
