skmultiflow.metrics package
===========================

Submodules
----------

.. toctree::

   skmultiflow.metrics.measure_collection

Module contents
---------------

.. automodule:: skmultiflow.metrics
    :members:
    :undoc-members:
    :show-inheritance:
