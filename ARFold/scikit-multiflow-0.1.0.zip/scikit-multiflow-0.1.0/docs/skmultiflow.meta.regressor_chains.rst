skmultiflow.meta.regressor\_chains module
=========================================

.. automodule:: skmultiflow.meta.regressor_chains
    :members:
    :undoc-members:
    :show-inheritance:
