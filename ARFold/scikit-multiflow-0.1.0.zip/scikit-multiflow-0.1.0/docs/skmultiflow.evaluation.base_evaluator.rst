skmultiflow.evaluation.base\_evaluator module
=============================================

.. automodule:: skmultiflow.evaluation.base_evaluator
    :members:
    :undoc-members:
    :show-inheritance:
