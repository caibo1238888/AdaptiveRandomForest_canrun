skmultiflow.trees.split\_criterion module
=========================================

.. automodule:: skmultiflow.trees.split_criterion
    :members:
    :undoc-members:
    :show-inheritance:
