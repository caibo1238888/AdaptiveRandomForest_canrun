skmultiflow.data.led\_generator module
======================================

.. automodule:: skmultiflow.data.led_generator
    :members:
    :undoc-members:
    :show-inheritance:
