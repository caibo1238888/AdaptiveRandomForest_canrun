skmultiflow.trees.hoeffding\_tree module
========================================

.. automodule:: skmultiflow.trees.hoeffding_tree
    :members:
    :undoc-members:
    :show-inheritance:
