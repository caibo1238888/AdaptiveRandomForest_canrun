skmultiflow.core package
========================

Submodules
----------

.. toctree::

   skmultiflow.core.base
   skmultiflow.core.base_object
   skmultiflow.core.instance_header
   skmultiflow.core.pipeline

Module contents
---------------

.. automodule:: skmultiflow.core
    :members:
    :undoc-members:
    :show-inheritance:
