skmultiflow.trees.info\_gain\_split\_criterion module
=====================================================

.. automodule:: skmultiflow.trees.info_gain_split_criterion
    :members:
    :undoc-members:
    :show-inheritance:
