skmultiflow.utils.data\_structures module
=========================================

.. automodule:: skmultiflow.utils.data_structures
    :members:
    :undoc-members:
    :show-inheritance:
