skmultiflow.trees.gaussian\_estimator module
============================================

.. automodule:: skmultiflow.trees.gaussian_estimator
    :members:
    :undoc-members:
    :show-inheritance:
