skmultiflow.trees.nominal\_attribute\_class\_observer module
============================================================

.. automodule:: skmultiflow.trees.nominal_attribute_class_observer
    :members:
    :undoc-members:
    :show-inheritance:
