skmultiflow.data.mixed\_generator module
========================================

.. automodule:: skmultiflow.data.mixed_generator
    :members:
    :undoc-members:
    :show-inheritance:
