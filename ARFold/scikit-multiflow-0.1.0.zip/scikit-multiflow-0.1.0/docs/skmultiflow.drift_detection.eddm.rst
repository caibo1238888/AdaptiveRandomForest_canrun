skmultiflow.drift\_detection.eddm module
========================================

.. automodule:: skmultiflow.drift_detection.eddm
    :members:
    :undoc-members:
    :show-inheritance:
