skmultiflow.meta.classifier\_chains module
==========================================

.. automodule:: skmultiflow.meta.classifier_chains
    :members:
    :undoc-members:
    :show-inheritance:
