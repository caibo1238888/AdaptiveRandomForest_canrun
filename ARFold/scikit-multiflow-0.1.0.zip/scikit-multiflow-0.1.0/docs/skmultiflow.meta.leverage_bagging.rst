skmultiflow.meta.leverage\_bagging module
=========================================

.. automodule:: skmultiflow.meta.leverage_bagging
    :members:
    :undoc-members:
    :show-inheritance:
