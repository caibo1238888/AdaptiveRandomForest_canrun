skmultiflow.data.file\_stream module
====================================

.. automodule:: skmultiflow.data.file_stream
    :members:
    :undoc-members:
    :show-inheritance:
