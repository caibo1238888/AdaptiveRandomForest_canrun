skmultiflow.evaluation.evaluate\_holdout module
===============================================

.. automodule:: skmultiflow.evaluation.evaluate_holdout
    :members:
    :undoc-members:
    :show-inheritance:
