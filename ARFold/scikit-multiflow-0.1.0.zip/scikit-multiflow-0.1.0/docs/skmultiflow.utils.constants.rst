skmultiflow.utils.constants module
==================================

.. automodule:: skmultiflow.utils.constants
    :members:
    :undoc-members:
    :show-inheritance:
