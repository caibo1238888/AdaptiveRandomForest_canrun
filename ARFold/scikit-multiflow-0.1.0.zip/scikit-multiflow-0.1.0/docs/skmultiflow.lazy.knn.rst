skmultiflow.lazy.knn module
===========================

.. automodule:: skmultiflow.lazy.knn
    :members:
    :undoc-members:
    :show-inheritance:
