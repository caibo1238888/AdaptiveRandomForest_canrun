skmultiflow.evaluation package
==============================

Submodules
----------

.. toctree::

   skmultiflow.evaluation.base_evaluator
   skmultiflow.evaluation.evaluate_holdout
   skmultiflow.evaluation.evaluate_prequential
   skmultiflow.evaluation.evaluate_stream_gen_speed

Module contents
---------------

.. automodule:: skmultiflow.evaluation
    :members:
    :undoc-members:
    :show-inheritance:
