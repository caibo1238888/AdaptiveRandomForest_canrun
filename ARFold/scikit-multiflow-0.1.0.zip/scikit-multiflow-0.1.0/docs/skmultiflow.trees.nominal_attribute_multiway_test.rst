skmultiflow.trees.nominal\_attribute\_multiway\_test module
===========================================================

.. automodule:: skmultiflow.trees.nominal_attribute_multiway_test
    :members:
    :undoc-members:
    :show-inheritance:
