skmultiflow.metrics.measure\_collection module
==============================================

.. automodule:: skmultiflow.metrics.measure_collection
    :members:
    :undoc-members:
    :show-inheritance:
