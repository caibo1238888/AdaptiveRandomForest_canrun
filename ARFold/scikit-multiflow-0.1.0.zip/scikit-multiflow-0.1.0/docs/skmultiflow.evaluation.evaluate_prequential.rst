skmultiflow.evaluation.evaluate\_prequential module
===================================================

.. automodule:: skmultiflow.evaluation.evaluate_prequential
    :members:
    :undoc-members:
    :show-inheritance:
