skmultiflow.data.led\_generator\_drift module
=============================================

.. automodule:: skmultiflow.data.led_generator_drift
    :members:
    :undoc-members:
    :show-inheritance:
