skmultiflow.data.hyper\_plane\_generator module
===============================================

.. automodule:: skmultiflow.data.hyper_plane_generator
    :members:
    :undoc-members:
    :show-inheritance:
