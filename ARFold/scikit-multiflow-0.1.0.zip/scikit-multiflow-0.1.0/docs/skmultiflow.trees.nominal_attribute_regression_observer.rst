skmultiflow.trees.nominal\_attribute\_regression\_observer module
=================================================================

.. automodule:: skmultiflow.trees.nominal_attribute_regression_observer
    :members:
    :undoc-members:
    :show-inheritance:
