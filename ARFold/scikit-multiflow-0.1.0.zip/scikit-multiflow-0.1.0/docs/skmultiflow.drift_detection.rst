skmultiflow.drift\_detection package
====================================

Submodules
----------

.. toctree::

   skmultiflow.drift_detection.adwin
   skmultiflow.drift_detection.base_drift_detector
   skmultiflow.drift_detection.ddm
   skmultiflow.drift_detection.eddm
   skmultiflow.drift_detection.page_hinkley

Module contents
---------------

.. automodule:: skmultiflow.drift_detection
    :members:
    :undoc-members:
    :show-inheritance:
