skmultiflow.core.instance\_header module
========================================

.. automodule:: skmultiflow.core.instance_header
    :members:
    :undoc-members:
    :show-inheritance:
