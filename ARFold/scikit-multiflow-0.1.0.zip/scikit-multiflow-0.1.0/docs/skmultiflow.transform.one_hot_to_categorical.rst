skmultiflow.transform.one\_hot\_to\_categorical module
======================================================

.. automodule:: skmultiflow.transform.one_hot_to_categorical
    :members:
    :undoc-members:
    :show-inheritance:
