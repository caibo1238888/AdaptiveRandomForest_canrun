skmultiflow.trees.regression\_hoeffding\_tree module
====================================================

.. automodule:: skmultiflow.trees.regression_hoeffding_tree
    :members:
    :undoc-members:
    :show-inheritance:
