skmultiflow.utils.statistics module
===================================

.. automodule:: skmultiflow.utils.statistics
    :members:
    :undoc-members:
    :show-inheritance:
