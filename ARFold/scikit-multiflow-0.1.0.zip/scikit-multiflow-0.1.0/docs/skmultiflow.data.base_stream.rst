skmultiflow.data.base\_stream module
====================================

.. automodule:: skmultiflow.data.base_stream
    :members:
    :undoc-members:
    :show-inheritance:
