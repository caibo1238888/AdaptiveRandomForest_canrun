skmultiflow.drift\_detection.page\_hinkley module
=================================================

.. automodule:: skmultiflow.drift_detection.page_hinkley
    :members:
    :undoc-members:
    :show-inheritance:
