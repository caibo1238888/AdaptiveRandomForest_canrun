skmultiflow.trees.attribute\_split\_suggestion module
=====================================================

.. automodule:: skmultiflow.trees.attribute_split_suggestion
    :members:
    :undoc-members:
    :show-inheritance:
