skmultiflow.lazy.knn\_adwin module
==================================

.. automodule:: skmultiflow.lazy.knn_adwin
    :members:
    :undoc-members:
    :show-inheritance:
