skmultiflow.visualization.evaluation\_visualizer module
=======================================================

.. automodule:: skmultiflow.visualization.evaluation_visualizer
    :members:
    :undoc-members:
    :show-inheritance:
