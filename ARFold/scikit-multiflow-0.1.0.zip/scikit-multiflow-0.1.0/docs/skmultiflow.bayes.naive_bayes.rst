skmultiflow.bayes.naive\_bayes module
=====================================

.. automodule:: skmultiflow.bayes.naive_bayes
    :members:
    :undoc-members:
    :show-inheritance:
