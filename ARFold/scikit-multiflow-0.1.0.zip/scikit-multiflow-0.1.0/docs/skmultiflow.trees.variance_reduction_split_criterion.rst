skmultiflow.trees.variance\_reduction\_split\_criterion module
==============================================================

.. automodule:: skmultiflow.trees.variance_reduction_split_criterion
    :members:
    :undoc-members:
    :show-inheritance:
