skmultiflow.evaluation.evaluate\_stream\_gen\_speed module
==========================================================

.. automodule:: skmultiflow.evaluation.evaluate_stream_gen_speed
    :members:
    :undoc-members:
    :show-inheritance:
