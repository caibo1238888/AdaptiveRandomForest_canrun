skmultiflow.data.agrawal\_generator module
==========================================

.. automodule:: skmultiflow.data.agrawal_generator
    :members:
    :undoc-members:
    :show-inheritance:
