skmultiflow.utils.file\_scripts module
======================================

.. automodule:: skmultiflow.utils.file_scripts
    :members:
    :undoc-members:
    :show-inheritance:
