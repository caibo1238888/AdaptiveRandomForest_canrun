skmultiflow.data package
========================

Submodules
----------

.. toctree::

   skmultiflow.data.agrawal_generator
   skmultiflow.data.base_stream
   skmultiflow.data.concept_drift_stream
   skmultiflow.data.data_stream
   skmultiflow.data.file_stream
   skmultiflow.data.hyper_plane_generator
   skmultiflow.data.led_generator
   skmultiflow.data.led_generator_drift
   skmultiflow.data.mixed_generator
   skmultiflow.data.multilabel_generator
   skmultiflow.data.pseudo_random_processes
   skmultiflow.data.random_rbf_generator
   skmultiflow.data.random_rbf_generator_drift
   skmultiflow.data.random_tree_generator
   skmultiflow.data.regression_generator
   skmultiflow.data.sea_generator
   skmultiflow.data.sine_generator
   skmultiflow.data.stagger_generator
   skmultiflow.data.synth
   skmultiflow.data.waveform_generator

Module contents
---------------

.. automodule:: skmultiflow.data
    :members:
    :undoc-members:
    :show-inheritance:
