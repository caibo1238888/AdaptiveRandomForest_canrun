skmultiflow.drift\_detection.ddm module
=======================================

.. automodule:: skmultiflow.drift_detection.ddm
    :members:
    :undoc-members:
    :show-inheritance:
