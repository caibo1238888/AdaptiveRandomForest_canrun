skmultiflow.trees.numeric\_attribute\_class\_observer\_gaussian module
======================================================================

.. automodule:: skmultiflow.trees.numeric_attribute_class_observer_gaussian
    :members:
    :undoc-members:
    :show-inheritance:
