skmultiflow.core.pipeline module
================================

.. automodule:: skmultiflow.core.pipeline
    :members:
    :undoc-members:
    :show-inheritance:
