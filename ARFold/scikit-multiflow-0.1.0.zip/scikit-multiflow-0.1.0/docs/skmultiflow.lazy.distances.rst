skmultiflow.lazy.distances module
=================================

.. automodule:: skmultiflow.lazy.distances
    :members:
    :undoc-members:
    :show-inheritance:
