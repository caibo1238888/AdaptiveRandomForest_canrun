skmultiflow.drift\_detection.adwin module
=========================================

.. automodule:: skmultiflow.drift_detection.adwin
    :members:
    :undoc-members:
    :show-inheritance:
