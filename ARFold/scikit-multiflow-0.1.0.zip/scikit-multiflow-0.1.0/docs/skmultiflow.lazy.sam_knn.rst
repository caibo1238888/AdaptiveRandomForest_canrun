skmultiflow.lazy.sam\_knn module
================================

.. automodule:: skmultiflow.lazy.sam_knn
    :members:
    :undoc-members:
    :show-inheritance:
