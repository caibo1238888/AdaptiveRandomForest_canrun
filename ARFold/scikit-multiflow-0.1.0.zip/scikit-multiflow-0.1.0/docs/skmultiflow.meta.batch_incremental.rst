skmultiflow.meta.batch\_incremental module
==========================================

.. automodule:: skmultiflow.meta.batch_incremental
    :members:
    :undoc-members:
    :show-inheritance:
