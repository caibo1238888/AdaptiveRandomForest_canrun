skmultiflow.drift\_detection.page\_hinkley
==========================================

.. automodule:: skmultiflow.drift_detection.page_hinkley

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      PageHinkley
   
   

   
   
   