skmultiflow.meta.classifier\_chains
===================================

.. automodule:: skmultiflow.meta.classifier_chains

   
   
   .. rubric:: Functions

   .. autosummary::
   
      P
      demo
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      ClassifierChain
      MCC
      ProbabilisticClassifierChain
   
   

   
   
   