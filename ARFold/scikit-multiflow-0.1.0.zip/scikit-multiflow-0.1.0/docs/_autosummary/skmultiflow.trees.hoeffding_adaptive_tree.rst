skmultiflow.trees.hoeffding\_adaptive\_tree
===========================================

.. automodule:: skmultiflow.trees.hoeffding_adaptive_tree

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      HAT
   
   

   
   
   