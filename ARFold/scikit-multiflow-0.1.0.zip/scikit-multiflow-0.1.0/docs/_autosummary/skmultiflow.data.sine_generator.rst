skmultiflow.data.sine\_generator
================================

.. automodule:: skmultiflow.data.sine_generator

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      SineGenerator
   
   

   
   
   