skmultiflow.data.agrawal\_generator
===================================

.. automodule:: skmultiflow.data.agrawal_generator

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      AGRAWALGenerator
   
   

   
   
   