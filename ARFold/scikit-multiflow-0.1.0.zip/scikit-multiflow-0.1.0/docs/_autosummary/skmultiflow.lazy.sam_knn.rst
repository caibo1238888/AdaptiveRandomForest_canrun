skmultiflow.lazy.sam\_knn
=========================

.. automodule:: skmultiflow.lazy.sam_knn

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      SAMKNN
      STMSizer
   
   

   
   
   