skmultiflow.bayes.naive\_bayes
==============================

.. automodule:: skmultiflow.bayes.naive_bayes

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      NaiveBayes
   
   

   
   
   