skmultiflow.data.file\_stream
=============================

.. automodule:: skmultiflow.data.file_stream

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      FileStream
   
   

   
   
   