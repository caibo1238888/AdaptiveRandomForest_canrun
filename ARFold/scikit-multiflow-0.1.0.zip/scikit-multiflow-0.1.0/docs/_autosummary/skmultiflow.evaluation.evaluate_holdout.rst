skmultiflow.evaluation.evaluate\_holdout
========================================

.. automodule:: skmultiflow.evaluation.evaluate_holdout

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      EvaluateHoldout
   
   

   
   
   