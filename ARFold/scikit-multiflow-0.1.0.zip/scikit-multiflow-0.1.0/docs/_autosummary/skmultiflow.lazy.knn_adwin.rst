skmultiflow.lazy.knn\_adwin
===========================

.. automodule:: skmultiflow.lazy.knn_adwin

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      KNNAdwin
   
   

   
   
   