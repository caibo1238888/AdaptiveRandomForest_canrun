skmultiflow.drift\_detection.eddm
=================================

.. automodule:: skmultiflow.drift_detection.eddm

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      EDDM
   
   

   
   
   