skmultiflow.data.hyper\_plane\_generator
========================================

.. automodule:: skmultiflow.data.hyper_plane_generator

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      HyperplaneGenerator
   
   

   
   
   