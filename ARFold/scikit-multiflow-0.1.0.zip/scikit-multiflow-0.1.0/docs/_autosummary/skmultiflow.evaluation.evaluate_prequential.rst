skmultiflow.evaluation.evaluate\_prequential
============================================

.. automodule:: skmultiflow.evaluation.evaluate_prequential

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      EvaluatePrequential
   
   

   
   
   