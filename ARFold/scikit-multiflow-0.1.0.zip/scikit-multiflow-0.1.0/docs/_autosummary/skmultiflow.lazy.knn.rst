skmultiflow.lazy.knn
====================

.. automodule:: skmultiflow.lazy.knn

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      KNN
   
   

   
   
   