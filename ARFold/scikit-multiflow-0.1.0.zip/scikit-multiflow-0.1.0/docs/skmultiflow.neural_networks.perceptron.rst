skmultiflow.neural\_networks.perceptron module
==============================================

.. automodule:: skmultiflow.neural_networks.perceptron
    :members:
    :undoc-members:
    :show-inheritance:
