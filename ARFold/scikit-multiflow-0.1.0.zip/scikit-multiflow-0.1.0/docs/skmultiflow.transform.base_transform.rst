skmultiflow.transform.base\_transform module
============================================

.. automodule:: skmultiflow.transform.base_transform
    :members:
    :undoc-members:
    :show-inheritance:
