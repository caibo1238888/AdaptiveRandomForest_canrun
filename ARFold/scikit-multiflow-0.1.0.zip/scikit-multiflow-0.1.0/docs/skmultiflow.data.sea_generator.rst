skmultiflow.data.sea\_generator module
======================================

.. automodule:: skmultiflow.data.sea_generator
    :members:
    :undoc-members:
    :show-inheritance:
