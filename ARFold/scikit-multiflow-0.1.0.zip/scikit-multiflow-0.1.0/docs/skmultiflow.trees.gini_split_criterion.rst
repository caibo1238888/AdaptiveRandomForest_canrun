skmultiflow.trees.gini\_split\_criterion module
===============================================

.. automodule:: skmultiflow.trees.gini_split_criterion
    :members:
    :undoc-members:
    :show-inheritance:
