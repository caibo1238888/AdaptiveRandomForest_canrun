skmultiflow
===========

.. toctree::
   :maxdepth: 4

   skmultiflow
