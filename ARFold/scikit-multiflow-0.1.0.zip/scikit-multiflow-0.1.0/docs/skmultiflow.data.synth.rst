skmultiflow.data.synth module
=============================

.. automodule:: skmultiflow.data.synth
    :members:
    :undoc-members:
    :show-inheritance:
