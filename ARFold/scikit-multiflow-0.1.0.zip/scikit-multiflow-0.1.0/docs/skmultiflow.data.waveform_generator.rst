skmultiflow.data.waveform\_generator module
===========================================

.. automodule:: skmultiflow.data.waveform_generator
    :members:
    :undoc-members:
    :show-inheritance:
