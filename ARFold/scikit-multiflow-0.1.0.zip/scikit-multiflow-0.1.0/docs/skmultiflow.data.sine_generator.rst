skmultiflow.data.sine\_generator module
=======================================

.. automodule:: skmultiflow.data.sine_generator
    :members:
    :undoc-members:
    :show-inheritance:
