skmultiflow.trees.hoeffding\_adaptive\_tree module
==================================================

.. automodule:: skmultiflow.trees.hoeffding_adaptive_tree
    :members:
    :undoc-members:
    :show-inheritance:
