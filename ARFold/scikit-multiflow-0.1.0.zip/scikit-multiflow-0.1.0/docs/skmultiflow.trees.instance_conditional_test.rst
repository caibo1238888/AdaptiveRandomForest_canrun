skmultiflow.trees.instance\_conditional\_test module
====================================================

.. automodule:: skmultiflow.trees.instance_conditional_test
    :members:
    :undoc-members:
    :show-inheritance:
