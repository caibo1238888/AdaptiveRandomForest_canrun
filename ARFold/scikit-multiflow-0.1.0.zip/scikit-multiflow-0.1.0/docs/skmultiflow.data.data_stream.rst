skmultiflow.data.data\_stream module
====================================

.. automodule:: skmultiflow.data.data_stream
    :members:
    :undoc-members:
    :show-inheritance:
