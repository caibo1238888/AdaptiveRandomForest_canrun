skmultiflow.trees.regression\_hoeffding\_adaptive\_tree module
==============================================================

.. automodule:: skmultiflow.trees.regression_hoeffding_adaptive_tree
    :members:
    :undoc-members:
    :show-inheritance:
