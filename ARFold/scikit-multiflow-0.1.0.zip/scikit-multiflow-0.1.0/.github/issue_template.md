### Expected behaviour

### Actual behaviour

### Steps to reproduce the behaviour


---
[*Note:* For comments and usage-related questions please consider the [users group](https://groups.google.com/forum/#!forum/scikit-multiflow-users).
