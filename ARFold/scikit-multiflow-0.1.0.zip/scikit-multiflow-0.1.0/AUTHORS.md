`scikit-multiflow` is a community effort.

# Contributors

The following people have contributed to `scikit-multiflow`'s development and maintenance.

* Jacob MONTIEL
* Albert BIFET
* Jesse READ
* Guilherme MATSUMOTO
* Peng YU
* Alessandro LONGOBARDI
* Heitor MURILO GOMES
* Anderson Carlos FERREIRA DA SILVA
* Bader DAMMAK
* Amine KRIFI
* Saulo MARTIELLO MASTELINI
